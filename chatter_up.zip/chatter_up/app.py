# Sapguian, Infante, Castro

# import necessary modules from flask
from flask import Flask, render_template, request, redirect,url_for, flash, session
from flask_socketio import SocketIO, send, emit
import socket
import os
from datetime import datetime  #for working with dates and times
import pytz                    #timezone handling



app = Flask(__name__)
# The __name__ variable is used to determine the root path of the application.  
# This allows Flask to locate resources like templates and static files.  

app.config['SECRET_KEY'] = 'test environment'
socketio = SocketIO(app)

# This constant represents the file where user information is stored. 
USER_FILE = 'users.txt'

# Example server-side code to send timestamp
timestamp = datetime.utcnow().isoformat()

def load_users():
    with open("users.txt", "r") as file:
        users = file.readlines()  # Read all lines from the file
        parsed_users = []
        for line in users:
            line = line.strip()  # Remove leading/trailing whitespace
            if not line:  # Skip empty lines
                continue
            try:
                parts = line.split(',')
                parsed_users.append({
                    'id': int(parts[0]),  # Convert first part to int
                    'username': parts[1].strip(),  # Strip whitespace
                    'password': parts[2].strip()   # Strip whitespace
                })
            except (ValueError, IndexError) as e:
                print(f"Skipping invalid line: {line} (Error: {e})")
                continue
        return parsed_users

def save_user(user_id,username,password):
    with open(USER_FILE,'a') as file:
        file.write(f"{user_id},{username},{password}\n")
        
# Global list to store chat messages
messages = []


@app.route('/register',methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']  # Get the entered username
        password = request.form['password']
        users = load_users()                 # Load all existing users from the user file
        
        # Check if the username already exists
        if any(user['username'] == username for user in users):
            flash('Username already exists. Please choose another')
            return redirect(url_for('register'))
      
        user_id = len(users) + 1               # Generate a unique user ID by incrementing the number of existing users
        save_user(user_id, username, password) # Save the new user's details in the users file
      
         # Show a success message and redirect to the login page      
        flash('Account created successfully. Please login')
        return redirect(url_for('login'))
    return render_template('register.html')

# This block of code is for the user login
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        user = next((user for user in users if user['username'] == username and user['password'] == password), None)
        
        # If user credentials are valid
        if user:
            # Store the username in the session
            session['username'] = username
            return redirect(url_for('index'))
        
        # if the username or password is invalid, an error will be display
        flash('Invalid username or password')
    return render_template('login.html')

# Define the route for logging out
@app.route('/logout')
def logout():
    session.pop('username',None)
    
    # Redirect the user to the login page once it click for logout
    return redirect(url_for('login'))

# Define the route for the home page
@app.route('/') 
def index():
    
    # Check if 'username' exists in the session (user is logged in)
    if 'username' in session:
        return render_template('chat.html', username=session['username'])
    
     # If not logged in, redirect to the login page
    return redirect(url_for('login'))


#Route for the search functionality
@app.route('/search', methods=['GET', 'POST'])
def search():
    
    # Check if the request method is POST
    if request.method == 'POST':
        search_query = request.form['search_query'].lower()
        users = load_users()
        matching_users = [user for user in users if search_query in user['username'].lower() and user['username'] != session.get('username')
]
        return render_template('search_results.html', users=matching_users)
    
    # Redirect to the index page if the request method is GET
    return redirect(url_for('index'))
#

# chats of user orig
@socketio.on('message') 
def handle_message(msg):
    username = session.get('username')
    timezone = pytz.timezone('Asia/Manila')          # Use your desired timezone
    timestamp = datetime.now(timezone).isoformat()   # Generate the current timestamp
  

    if username:
        
        # Logs the message and username to the server console for debugging or monitoring purposes.
        print(f"{username}:{msg}")
        send({'msg':msg, 'username': username, 'timestamp': timestamp}, broadcast=True)

if __name__ == '__main__':
    socketio.run(app,debug=True)